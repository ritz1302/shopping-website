import datetime

from django.db import models
from django.utils import timezone
from django.forms.extras.widgets import SelectDateWidget
from django.contrib.auth.models import User
from django.contrib.auth.models import AbstractUser
from simple_email_confirmation import SimpleEmailConfirmationUserMixin
# Create your models here.

class Item(models.Model):
    item_name = models.CharField(max_length=200)
    pub_date = models.DateTimeField('Date Published')
    image1 = models.ImageField(blank=True)
    image2 = models.ImageField(blank=True)
    image3 = models.ImageField(blank=True)
    image4 = models.ImageField(blank=True)
    image5 = models.ImageField(blank=True)
    image6 = models.ImageField(blank=True)
    price = models.FloatField()
    description = models.CharField(max_length=500)
    discount = models.IntegerField(blank=True)
    brand = models.CharField(max_length=200)
    catagory = models.CharField(max_length=200)
    color = models.CharField(max_length=200)
    def __str__(self):
        return self.item_name

class UserProfile(models.Model):
    user = models.OneToOneField(User)
    activation_key = models.CharField(max_length=40, blank=True)
    key_expires = models.DateTimeField(default=datetime.date.today())
      
    def __str__(self):
        return self.user.username

    class Meta:
        verbose_name_plural=u'User profiles'
