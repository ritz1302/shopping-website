from django.conf import settings
from django.contrib import auth
from django.contrib.auth import views, authenticate, login, update_session_auth_hash, update_session_auth_hash, logout as auth_logout
from django.contrib.auth.models import User, AbstractUser
from django.core.mail import send_mail
from django.core.context_processors import csrf
from django.http import HttpResponseRedirect, HttpResponse
from django.shortcuts import render_to_response, redirect, render, get_object_or_404
from django.template import RequestContext
from django.contrib.auth.hashers import make_password
from django.utils import timezone
from .forms import *
from .models import *
from carton.cart import Cart
from paypal.standard.forms import PayPalPaymentsForm
import hashlib, datetime, random, paypalrestsdk
from hashlib import sha1 as sha_constructor
# Create your views here.

def index(request):
    latest_item_list = Item.objects.filter(item_name="from the blog")
    list1 = Item.objects.filter(description="humour")
    list2 = Item.objects.filter(description="Non-charac")
    context = {'latest_item_list': latest_item_list, 'list1': list1, 'list2': list2}
    return render(request, 'shop/index.html', context)

def userlogin(request):
    state = "If you have an account, Please log in below..."
    username = password = ''
    if request.POST:
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(username=username, password=password)
        if user is not None:
            if user.is_active:
                login(request, user)
                state = "You're successfully logged in!"
            else:
                state = "Your account is not active, please contact the site admin."
        else:
            state = "Your username and/or password were incorrect."

    return render_to_response('shop/login.html',{'state':state, 'username': username}, context_instance=RequestContext(request))

def men(request):
    checkbox=""
    checkbox2=""
    select_color=""
    radio=0
    if request.POST:
        radio = request.POST.get('radio')
        checkbox=request.POST.get('checkbox')
        checkbox2=request.POST.get('checkbox2')
        select_color=request.POST.get('select_color')
        
        if checkbox!="" and checkbox2!="" and select_color!="" and radio:
            latest_item_list =Item.objects.filter(description="It is a long establishe", catagory=checkbox, brand=checkbox2, color=select_color, discount=radio)

        elif checkbox!="" and checkbox2!="" and select_color!="":
            latest_item_list =Item.objects.filter(description="It is a long establishe", catagory=checkbox, brand=checkbox2, color=select_color)

        elif checkbox!="" and checkbox2!="" and radio:
            latest_item_list =Item.objects.filter(description="It is a long establishe", catagory=checkbox, brand=checkbox2, discount=radio)

        elif checkbox!="" and select_color!="" and radio:
            latest_item_list =Item.objects.filter(description="It is a long establishe", discount=radio, catagory=checkbox, color=select_color)
            
        elif radio and checkbox2!="" and select_color!="":
            latest_item_list =Item.objects.filter(description="It is a long establishe", brand=checkbox2, color=select_color, discount=radio)

        elif checkbox!="" and checkbox2!="":
            latest_item_list =Item.objects.filter(description="It is a long establishe", catagory=checkbox, brand=checkbox2)

        elif checkbox!="" and select_color!="":
            latest_item_list =Item.objects.filter(description="It is a long establishe", catagory=checkbox, color=select_color)

        elif checkbox!="" and radio:
            latest_item_list =Item.objects.filter(description="It is a long establishe", catagory=checkbox, discount=radio)

        elif checkbox2!="" and select_color!="":
            latest_item_list =Item.objects.filter(description="It is a long establishe", brand=checkbox2, color=select_color)

        elif radio and checkbox2!="":
            latest_item_list =Item.objects.filter(description="It is a long establishe", brand=checkbox2, discount=radio)

        elif radio and select_color!="":
            latest_item_list =Item.objects.filter(description="It is a long establishe", color=select_color, discount=radio)

        elif checkbox!="":
            latest_item_list =Item.objects.filter(description="It is a long establishe", catagory=checkbox)

        elif checkbox2!="":
            latest_item_list =Item.objects.filter(description="It is a long establishe", brand=checkbox2)

        elif select_color!="":
            latest_item_list =Item.objects.filter(description="It is a long establishe", color=select_color)

        elif radio or checkbox=="" or checkbox2=="" or select_color=="":
            latest_item_list =Item.objects.filter(description="It is a long establishe", discount=radio)

        else:
            latest_item_list =Item.objects.filter(description="It is a long establishe") 


    else:
        latest_item_list = Item.objects.filter(description="It is a long establishe")
        
    context = {'latest_item_list': latest_item_list}
        
    return render(request, 'shop/men.html', context)

def error(request):
    state = "You ' ve Failed."
    return render(request, 'shop/error.html', {'state': state})

def register(request):
    state = ""
    if request.POST:
        form = CreateAcount(request.POST)
        if form.is_valid():
            new_user = User.objects.create_user(username=request.POST['username'], 
                                                email=request.POST['email'],
                                                first_name=request.POST['first_name'],
                                                last_name=request.POST['last_name'],
                                                password=request.POST['password'])

            user_email = request.POST['email']
            #new_user.is_active()= False
            #send_mail(subject, message, from_email, to_list, fail_silently=True)
            subject = 'Thank you for registration'
            message = 'Welcome new user.\n here is the link to active your acount.\nhttp://localhost:8000/shop/userlogin/'
            from_email = settings.EMAIL_HOST_USER
            to_list = [user_email, settings.EMAIL_HOST_USER]

            send_mail(subject, message, from_email, to_list, fail_silently=True)
            state = "thanks for register, you may login now."
            return HttpResponseRedirect('/shop/userlogin')


    else:
        form = CreateAcount()

    args = {}
    args.update(csrf(request))

    args['form'] = form
    return render(request, 'shop/register.html', args)

def index_single(request):
    return render(request, 'shop/index_single.html')

def single(request, item_id):
    product = get_object_or_404(Item, pk=item_id)
    latest_item_list = Item.objects.filter(description="Contrary to popular belief")
    context = {'product': product, 'latest_item_list': latest_item_list}
    return render(request, 'shop/single.html', context)

def terms_and_conditions(request):
    return render(request, 'shop/terms_and_conditions.html')

def about(request):
    latest_item_list = Item.objects.filter(description="Contrary to popular belief")
    context = {'latest_item_list': latest_item_list}
    return render(request, 'shop/about.html', context)

def checkout(request):
    return render(request, 'shop/checkout.html')

def contact(request):
    return render(request, 'shop/contact.html')

def FAQ(request):
    return render(request, 'shop/FAQ.html')

def payments(request):
    return render(request, 'shop/payments.html')

def cancellation_and_return(request):
    return render(request, 'shop/return.html')

def search(request):
    if 'q' in request.GET:
        q = request.GET['q']
        if not q:
            error = True
        else:
            items = Item.objects.filter(item_name=q)
            return render(request, 'shop/search_result.html',
                {'items': items, 'query': q})
    return render(request, 'shop/index.html')

def forgot_password(request):
    state = "give your email address to reset your password."
    if 'user_mail' in request.GET:
        user_mail = request.GET['user_mail']
        if not user_mail:
            error = True
        else:
            user_email = user_mail
            #send_mail(subject, message, from_email, to_list, fail_silently=True)
            subject = 'Password reset link'
            message = 'Here is the link to reset your password.\nhttp://localhost:8000/shop/reset_password'
            from_email = settings.EMAIL_HOST_USER
            to_list = [user_email, settings.EMAIL_HOST_USER]

            send_mail(subject, message, from_email, to_list, fail_silently=True)
            state = "your password reset link is sent to your email address. Please check your email."
            return render(request, 'shop/forgot_password.html',
                {'state': state})
    return render(request, 'shop/forgot_password.html', {'state':state})


def reset_password(request):
    state = "Please put your new password here"
    if request.POST:
        password1= request.POST['password1']
        password2= request.POST['password2']
        user_mail= request.POST['user_mail']
        
        if password1 != password2:
            state = "password does not match"
            return render(request, 'shop/reset_password.html', {'state': state})
        else:
            return HttpResponseRedirect('/shop/')
    return render(request, 'shop/reset_password.html', {'state': state})


def seller_acount(request):
    state = ""
    if request.POST:
        form = CreateAcount2(request.POST)
        if form.is_valid():
            u_name="seller_"
            u_name = u_name + request.POST['first_name'] + request.POST['last_name']
            pwd = request.POST['password']
            
            new_user = User.objects.create_user(username=u_name, 
                                                email=request.POST['email'],
                                                first_name=request.POST['first_name'],
                                                last_name=request.POST['last_name'],
                                                password=request.POST['password'])

            user_email = request.POST['email']
            #new_user.is_active()= False
            #send_mail(subject, message, from_email, to_list, fail_silently=True)
            subject = 'Thank you for registration'
            message = "Welcome new seller.\n username is : %s \n password is : %s\n here is the link to active your acount.\n http://localhost:8000/shop/sellerlogin/" % (u_name, pwd)
            from_email = settings.EMAIL_HOST_USER
            to_list = [user_email, settings.EMAIL_HOST_USER]

            send_mail(subject, message, from_email, to_list, fail_silently=True)
            state = "thanks for register, you may login now."
            return HttpResponseRedirect('/shop/thankyou')


    else:
        form = CreateAcount2()

    args = {}
    args.update(csrf(request))

    args['form'] = form
    return render(request, 'shop/seller_acount.html', args)



def add(request, item_id):
    cart = Cart(request.session)
    product = Item.objects.get(id=item_id)
    cart.add(product, price=product.price)
    return HttpResponseRedirect('/shop/show')
    

def show(request):
    return render(request, 'shop/show_cart.html')

def remove(request, item_id):
    cart = Cart(request.session)
    product = Item.objects.get(id=item_id)
    cart.remove(product)
    return HttpResponseRedirect('/shop/show')

def remove_single(request, item_id):
    cart = Cart(request.session)
    product = Item.objects.get(id=item_id)
    cart.remove_single(product)
    return HttpResponseRedirect('/shop/show')

def empty(request):
    cart= Cart(request.session)
    cart.clear()
    return HttpResponseRedirect('/shop/')


def thankyou(request):
    return render(request, 'shop/thankyou.html')

def sellerlogin(request):
    state = "If you have an seller account, Please log in below..."
    username = password = ''
    if request.POST:
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(username=username, password=password)
        if user is not None:
            if user.is_active:
                login(request, user)
                state = "You're successfully logged in!"
            else:
                state = "Your account is not active, please contact the site admin."
        else:
            state = "Your username and/or password were incorrect."

    return render_to_response('shop/sellerlogin.html',{'state':state, 'username': username}, context_instance=RequestContext(request))

def view_for_money(request):

    # What you want the button to do.
    paypal_dict = {
        "business": settings.PAYPAL_RECEIVER_EMAIL,
        "amount": "10000000.00",
        "item_name": "name of the item",
        "invoice": "unique-invoice-id",
        "notify_url": "https://localhost:8000/shop/show/paypal" + reverse('paypal-ipn'),
        "return_url": "https://localhost:8000/your-return-location/",
        "cancel_return": "https://localhost:8000/your-cancel-location/",

    }

    # Create the instance.
    form = PayPalPaymentsForm(initial=paypal_dict)
    context = {"form": form}
    return render(request, "cart_payment.html", context)



def youraction(request):
    payment = paypalrestsdk.Payment({
      "intent": "sale",
      "payer": {
          
          "payment_method": "paypal" },
          "redirect_urls": {
          "return_url": "https://devtools-paypal.com/guide/pay_paypal/python?success=true",
          "cancel_url": "https://devtools-paypal.com/guide/pay_paypal/python?cancel=true" },

        "transactions": [ {
        "amount": {
          "total": "12",
          "currency": "USD" },
        "description": "creating a payment" } ] } )

    payment.create()
    return HttpResponse("paid")
