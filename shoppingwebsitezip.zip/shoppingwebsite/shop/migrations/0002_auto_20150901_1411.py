# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('shop', '0001_initial'),
    ]

    operations = [
        migrations.AlterField(
            model_name='item',
            name='image1',
            field=models.ImageField(upload_to='', blank=True),
        ),
        migrations.AlterField(
            model_name='item',
            name='image2',
            field=models.ImageField(upload_to='', blank=True),
        ),
        migrations.AlterField(
            model_name='item',
            name='image3',
            field=models.ImageField(upload_to='', blank=True),
        ),
        migrations.AlterField(
            model_name='item',
            name='image4',
            field=models.ImageField(upload_to='', blank=True),
        ),
        migrations.AlterField(
            model_name='item',
            name='image5',
            field=models.ImageField(upload_to='', blank=True),
        ),
        migrations.AlterField(
            model_name='item',
            name='image6',
            field=models.ImageField(upload_to='', blank=True),
        ),
    ]
