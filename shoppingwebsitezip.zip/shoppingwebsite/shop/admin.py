from django.contrib import admin
from .models import Item
from carton.cart import Cart
# Register your models here.

class ItemAdmin(admin.ModelAdmin):
    fieldsets = [
        (None,               {'fields': ['item_name']}),
        ('Date information', {'fields': ['pub_date'], 'classes': ['collapse']}),
        ('price',             {'fields': ['price']}),
        ('description',        {'fields': ['description']}),
        ('image1',            {'fields': ['image1']}),
        ('image2',            {'fields': ['image2']}),
        ('image3',            {'fields': ['image3']}),
        ('image4',            {'fields': ['image4']}),
        ('image5',            {'fields': ['image5']}),
        ('image6',            {'fields': ['image6']}),
        ('discount',          {'fields': ['discount']}),
        ('catagory',           {'fields': ['catagory']}),
        ('brand',             {'fields': ['brand']}),
        ('color',             {'fields': ['color']}),
    ]
    list_display = ('id', 'item_name', 'pub_date', 'price', 'discount', 'catagory', 'brand', 'color', 'description', 'image1', 'image2', 'image3', 'image4', 'image5', 'image6',)
    list_filter = ['pub_date']
    search_fields = ['item_name']
    ordering = ('id',)

admin.site.register(Item, ItemAdmin)
