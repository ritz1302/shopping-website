from django.conf.urls import include, url

from . import views

urlpatterns = [
    url('^', include('django.contrib.auth.urls')),
    url(r'^$', views.index, name='index'),
    url(r'^men/$', views.men, name='men'),
    url(r'^error/$', views.error, name='error'),
    url(r'^about/$', views.about, name='about'),
    url(r'^userlogin/$', views.userlogin, name='userlogin'),
    url(r'^sellerlogin/$', views.sellerlogin, name='sellerlogin'),
    url(r'^index_single/$', views.index_single, name='index_single'),
    url(r'^(?P<item_id>[0-9]+)/single$', views.single, name='single'),
    url(r'^contact/$', views.contact, name='contact'),
    url(r'^register/$', views.register, name='register'),
    url(r'^FAQ/$', views.FAQ, name='FAQ'),
    url(r'^cancellation_and_return/$', views.cancellation_and_return, name='cancellation_and_return'),
    url(r'^payments/$', views.payments, name='payments'),
    url(r'^terms_and_conditions/$', views.terms_and_conditions, name='terms_and_conditions'),
    url(r'^search/$', views.search, name='search'),
    url(r'^forgot_password/$', views.forgot_password, name='forgot_password'),
    url(r'^reset_password/$', views.reset_password, name='reset_password'),
    url(r'^user/password/reset/$', 
        'django.contrib.auth.views.password_reset', 
        {'post_reset_redirect' : '/shop/user/password/reset/done/'},
        name="password_reset"),
    url(r'^user/password/reset/done/$',
        'django.contrib.auth.views.password_reset_done'),
    url(r'^user/password/reset/(?P<uidb36>[0-9A-Za-z]+)-(?P<token>.+)/$', 
        'django.contrib.auth.views.password_reset_confirm', 
        {'post_reset_redirect' : '/user/password/done/'}),
    url(r'^user/password/done/$', 
        'django.contrib.auth.views.password_reset_complete'),
    url(r'^seller_acount/$', views.seller_acount, name='seller_acount'),
    url(r'^(?P<item_id>[0-9]+)/add/$', views.add, name='add'),
    url(r'^show/$', views.show, name='show'),
    url(r'^(?P<item_id>[0-9]+)/remove/$', views.remove, name='remove'),
    url(r'^(?P<item_id>[0-9]+)/remove_single/$', views.remove_single, name='remove_single'),
    url(r'^empty/$', views.empty, name='empty'),
    url(r'^thankyou/$', views.thankyou, name='thankyou'),
    url(r'^view_for_money/$', views.view_for_money, name='view_for_money'),
    url(r'^show/paypal/$', include('paypal.standard.ipn.urls')),
    url(r'^youraction/$', views.youraction, name='youraction'),
    

    
]
